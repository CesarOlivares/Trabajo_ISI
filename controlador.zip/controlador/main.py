import streamlit as st
import sys
import os
import time
import pandas as pd

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from modelo.usuario import Usuario
from controlador.logica import cargar_flota, cargar_estado_rapido, guardar_estado_rapido, procesar_archivo_subido, restaurar_fabrica
from vista.interfaz import renderizar_login, renderizar_dashboard_completo

st.set_page_config(layout="wide", page_title="BioVertia Pro")

# --- FUNCIONES DE ESTADO ---
def recuperar_sesion():
    if "usuario" in st.query_params and st.query_params["usuario"] == "admin":
        return Usuario("admin", "admin")
    return None

def inicializar_datos():
    estado_guardado = cargar_estado_rapido()
    if estado_guardado:
        return estado_guardado
    return cargar_flota()

# --- CARGA INICIAL ---
if "app_state" not in st.session_state:
    st.session_state["app_state"] = {
        "usuario": recuperar_sesion(), 
        "datos": inicializar_datos()
    }

# --- VISTA: LOGIN ---
if st.session_state["app_state"]["usuario"] is None:
    u, p, btn = renderizar_login()
    if btn:
        admin = Usuario("admin", "admin")
        if admin.es_valido(u, p):
            st.session_state["app_state"]["usuario"] = admin
            st.query_params["usuario"] = "admin"
            
            if "ultimo_archivo_id" in st.session_state:
                del st.session_state["ultimo_archivo_id"]

            nueva_flota = cargar_flota()
            for id_camion, camion in nueva_flota.items():
                camion.reiniciar_recorrido()
            st.session_state["app_state"]["datos"] = nueva_flota
            guardar_estado_rapido(nueva_flota)
            st.rerun()
        else:
            st.error("Credenciales incorrectas")

# --- VISTA: DASHBOARD ---
else:
    flota = st.session_state["app_state"]["datos"]
    if not flota: st.stop()

    camion_obj, activo, reset_btn, archivo_subido, restaurar_btn = renderizar_dashboard_completo(flota)

    # 1. LÓGICA DE UPLOAD
    if archivo_subido is not None:
        archivo_id = f"{archivo_subido.name}-{archivo_subido.size}"
        if "ultimo_archivo_id" not in st.session_state or st.session_state["ultimo_archivo_id"] != archivo_id:
            exito = procesar_archivo_subido(archivo_subido)
            if exito:
                st.session_state["ultimo_archivo_id"] = archivo_id
                nueva_flota = cargar_flota()
                st.session_state["app_state"]["datos"] = nueva_flota
                st.toast("✅ Datos cargados correctamente!", icon="📂")
                time.sleep(1)
                st.rerun()
            else:
                st.error("Error al procesar el archivo.")

    # 2. LÓGICA RESTAURAR FÁBRICA
    if restaurar_btn:
        restaurar_fabrica()
        if "ultimo_archivo_id" in st.session_state:
            del st.session_state["ultimo_archivo_id"]
        
        nueva_flota = cargar_flota()
        st.session_state["app_state"]["datos"] = nueva_flota
        st.toast("♻️ Sistema restaurado a valores de fábrica.", icon="🔄")
        time.sleep(1)
        st.rerun()

    # 3. Lógica Reset Sensor
    if reset_btn:
        camion_obj.reiniciar_recorrido()
        guardar_estado_rapido(flota)
        st.rerun()

    # 4. BUCLE DE SIMULACIÓN (CORREGIDO PARA GUARDAR TODO)
    if activo:
        time.sleep(1.5) 
        
        for key, cam in flota.items():
            
            # Solo si está en camino avanzamos
            if cam.estado == "En camino":
                cam.simular_avance()
                
                # Verificamos de nuevo si sigue en camino tras avanzar
                if cam.estado == "En camino":
                    
                    # --- CAMBIO CLAVE AQUÍ ---
                    # Antes teníamos un 'if' para guardar solo el camión seleccionado.
                    # Ahora pasamos 'cam.id_camion' SIEMPRE.
                    # Esto obliga al sistema a escribir en el Excel hoja por hoja.
                    cam.asignacion.leer_dato(id_hoja_excel=cam.id_camion)
        
        guardar_estado_rapido(flota)
        st.rerun()
