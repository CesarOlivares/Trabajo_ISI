import pandas as pd
import os
import sys
import pickle 
import random 

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from modelo.sensor import Sensor
from modelo.camion import Camion

FILE_NAME = "../camiones.xlsx"
PICKLE_NAME = "estado_sesion.pkl" 

CIUDADES_CHILE = ["Santiago", "Valparaíso", "Concepción", "Antofagasta", "Puerto Montt", "La Serena", "Temuco", "Arica"]

def gestionar_excel_inicial():
    if not os.path.exists(FILE_NAME):
        try:
            with pd.ExcelWriter(FILE_NAME, engine='openpyxl') as writer:
                for i in range(1, 21):
                    id_c = f"C-{i:03d}"
                    s = Sensor(1000+i, 10.0, -5.0)
                    meta = pd.DataFrame([{"Serial_ID": 1000+i, "Umbral_Max": 10, "Umbral_Min": -5}])
                    meta.to_excel(writer, sheet_name=id_c, startrow=0, index=False)
                    s.historial_db.to_excel(writer, sheet_name=id_c, startrow=3, index=False)
        except Exception as e:
            print(f"Error creando Excel: {e}")

def cargar_flota():
    gestionar_excel_inicial()
    flota = {}
    try:
        xls = pd.ExcelFile(FILE_NAME)
        for hoja in xls.sheet_names:
            try:
                meta = pd.read_excel(xls, hoja, nrows=1)
                hist = pd.read_excel(xls, hoja, skiprows=3)
                
                s = Sensor(meta.iloc[0]["Serial_ID"], meta.iloc[0]["Umbral_Max"], 
                           meta.iloc[0]["Umbral_Min"], historial_inicial=hist)
                
                parts = hoja.split("-")
                num = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 0
                
                origen = random.choice(CIUDADES_CHILE)
                destino = random.choice([c for c in CIUDADES_CHILE if c != origen])
                
                if not s.cola_simulacion.empty:
                    duracion = len(s.cola_simulacion)
                else:
                    duracion = random.randint(25, 80)
                
                c = Camion(hoja, f"JJ-KL-{num:02d}", s, origen, destino, duracion_estimada=duracion)
                flota[str(c)] = c
            except:
                continue
    except:
        return {}
    return flota

def guardar_estado_rapido(flota):
    try:
        with open(PICKLE_NAME, 'wb') as f:
            pickle.dump(flota, f)
    except Exception as e:
        print(f"Error guardando estado: {e}")

def cargar_estado_rapido():
    if os.path.exists(PICKLE_NAME):
        try:
            with open(PICKLE_NAME, 'rb') as f:
                return pickle.load(f)
        except:
            return None 
    return None

def procesar_archivo_subido(archivo_uploaded):
    try:
        with open(FILE_NAME, "wb") as f:
            f.write(archivo_uploaded.getbuffer())
        if os.path.exists(PICKLE_NAME):
            os.remove(PICKLE_NAME)
        return True
    except Exception as e:
        print(f"Error procesando upload: {e}")
        return False

# --- NUEVA FUNCIÓN ---
def restaurar_fabrica():
    """Borra el Excel actual y el pickle para forzar un reinicio aleatorio total"""
    try:
        if os.path.exists(FILE_NAME):
            os.remove(FILE_NAME) # Borramos el Excel del usuario
        if os.path.exists(PICKLE_NAME):
            os.remove(PICKLE_NAME) # Borramos la memoria
        return True
    except Exception as e:
        print(f"Error restaurando fábrica: {e}")
        return False
