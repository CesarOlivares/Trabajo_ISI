import random

class Camion:
    def __init__(self, id_camion: str, patente: str, sensor_asignado, origen="Santiago", destino="Valparaíso", estado="En camino", duracion_estimada=30):
        self.id_camion = id_camion
        self.patente = patente
        self.asignacion = sensor_asignado
        
        self.origen = origen
        self.destino = destino
        self.estado = estado 
        
        self.duracion_estimada = duracion_estimada 
        self.pasos_completados = 0                 
        
        if estado == "Finalizado":
            self.pasos_completados = self.duracion_estimada

    def finalizar_recorrido(self):
        self.estado = "Finalizado"
        self.pasos_completados = self.duracion_estimada 

    def reiniciar_recorrido(self):
        self.estado = "En camino"
        self.pasos_completados = 0 
        
        # 1. Reiniciamos el sensor (recarga la cola de datos desde el backup del Excel)
        self.asignacion.reiniciar()
        
        # 2. INTELIGENCIA DE REINICIO
        # Verificamos si el sensor tiene datos reales encolados
        if not self.asignacion.cola_simulacion.empty:
            # Si hay archivo cargado, la duración se ajusta a los datos reales
            self.duracion_estimada = len(self.asignacion.cola_simulacion)
            # Nota: No cambiamos origen/destino para mantener la consistencia del "Replay"
            
        else:
            # Si estamos en modo 100% aleatorio (sin archivo), inventamos nueva ruta y tiempo
            ciudades = ["Santiago", "Valparaíso", "Concepción", "Antofagasta", "Puerto Montt", "La Serena", "Temuco", "Arica", "Iquique", "Punta Arenas"]
            if self.origen in ciudades:
                self.origen = random.choice(ciudades)
                self.destino = random.choice([c for c in ciudades if c != self.origen])
            
            self.duracion_estimada = random.randint(20, 60)

    def simular_avance(self):
        if self.estado == "En camino":
            self.pasos_completados += 1
            if self.pasos_completados >= self.duracion_estimada:
                self.finalizar_recorrido()
                return True 
        return False

    @property
    def porcentaje_avance(self):
        if self.duracion_estimada == 0: return 1.0 # Si no hay duración, asumimos terminado
        pct = self.pasos_completados / self.duracion_estimada
        return min(pct, 1.0) 

    def __str__(self):
        icon = "🟢" if self.estado == "En camino" else "🔴"
        return f"{icon} {self.id_camion} | {self.patente}"


    
