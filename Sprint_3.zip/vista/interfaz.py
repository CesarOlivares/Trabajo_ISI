import os
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FILE_NAME = os.path.join(BASE_DIR, "camiones.xlsx")

import streamlit as st
import altair as alt
import pandas as pd
import numpy as np
import datetime

def cargar_css_personalizado():
    st.markdown("""
        <style>
        [data-testid="stMetricValue"] { font-size: 1.8rem; }
        div[data-testid="stVerticalBlock"] > div { padding-top: 0.5rem; }
        </style>
    """, unsafe_allow_html=True)

def renderizar_login():
    st.markdown("<br><br>", unsafe_allow_html=True) 
    col1, col2, col3 = st.columns([1, 1.5, 1]) 
    with col2:
        with st.container(border=True):
            st.markdown("<h2 style='text-align: center;'>Acceso</h2>", unsafe_allow_html=True)
            with st.form("login_form"):
                u = st.text_input("Usuario", placeholder="admin")
                p = st.text_input("Contraseña", type="password", placeholder="••••••")
                st.write("")
                btn = st.form_submit_button("Ingresar al Sistema", type="primary", use_container_width=True)
            return u, p, btn
    return None, None, False

def renderizar_dashboard_completo(flota_camiones):
    cargar_css_personalizado()
    
    if "monitor_live" not in st.session_state:
        st.session_state["monitor_live"] = False

    # --- HEADER ---
    col_logo, col_titulo, col_logout = st.columns([1, 4, 1])
    with col_titulo:
        st.title("Monitor de Temperatura")
    with col_logout:
        st.write("")
        if st.button("Cerrar Sesión", type="secondary"):
            st.session_state["app_state"]["usuario"] = None
            st.query_params.clear()
            st.session_state["monitor_live"] = False
            
            # Limpieza profunda al salir
            if "ultimo_archivo_id" in st.session_state:
                del st.session_state["ultimo_archivo_id"]
            
            st.rerun()
    st.divider()

    col_izq, col_centro, col_der = st.columns([1.2, 3, 1.2])

    archivo_subido = None 
    restaurar_btn = False 
    
    # === COLUMNA IZQUIERDA ===
    with col_izq:
        st.subheader("Flota Activa")
        busqueda = st.text_input("Buscar Camión", placeholder="ID o Patente").upper()
        opciones = list(flota_camiones.keys())
        filtradas = [op for op in opciones if busqueda in op.upper()]
        
        seleccion = None
        with st.container(height=350, border=True):
            if filtradas:
                seleccion = st.radio("Unidades:", options=filtradas, label_visibility="collapsed")
            else:
                st.warning("No se encontraron camiones.")
                st.stop()
        
        st.write("---")
        st.subheader("Gestión de Datos")
        
        with st.container(border=True):
            st.info("Subir Excel para simulación real.")
            archivo_subido = st.file_uploader("Cargar Archivo", type=["xlsx"], label_visibility="collapsed")
            
            st.write("")
            st.markdown("---")
            st.caption("¿Problemas con el archivo?")
            restaurar_btn = st.button("Restaurar simulación", type="primary", use_container_width=True, help="Borra el archivo subido y vuelve a generar datos aleatorios.")

    camion_actual = flota_camiones[seleccion]
    sensor_actual = camion_actual.asignacion

    # === COLUMNA CENTRAL ===
    with col_centro:
        c1, c2, c3 = st.columns([2, 1, 1])
        c1.subheader(f"Unidad: {camion_actual.id_camion}")
        with c2: st.info(f"🛫 **Origen:**\n{camion_actual.origen}")
        with c3: st.success(f"🛬 **Destino:**\n{camion_actual.destino}")
            
        if not sensor_actual.historial_db.empty:
            df = sensor_actual.historial_db.copy()
            VENTANA_VISUAL = 20
            df_visual = df.tail(VENTANA_VISUAL)
            
            st.write("Registro de Temperaturas")
            df_melt = df_visual.melt('Hora', ['Temp [°C]', 'LimSup', 'LimInf'], 'Tipo', 'Temp')
            color_scale = alt.Scale(domain=['Temp [°C]', 'LimSup', 'LimInf'], range=['#2ECC71', '#E74C3C', '#3498DB'])
            
            base = alt.Chart(df_melt).encode(
                x=alt.X('Hora', title='Hora', axis=alt.Axis(labels=True, labelAngle=-45)),
                y=alt.Y('Temp', title='Temp [°C]', scale=alt.Scale(zero=False, padding=1)),
                color=alt.Color('Tipo', scale=color_scale, legend=alt.Legend(title="Variables", orient="top"))
            )
            chart = (base.mark_line(strokeWidth=3) + base.mark_circle(size=60).encode(
                tooltip=['Hora', 'Temp', 'Tipo']
            )).properties(height=320).interactive()
            st.altair_chart(chart, use_container_width=True)
            
            with st.expander("Ver Tabla de Eventos Críticos", expanded=True):
                criticos = df[ df["Alertas"] != "Normal" ].copy()
                if not criticos.empty:
                    st.dataframe(criticos[["Hora", "Temp [°C]", "Alertas"]].sort_values("Hora", ascending=False), use_container_width=True, hide_index=True, height=200)
                else:
                    st.info("Sin anomalías.")

            st.write("Estadísticas del Viaje")
            with st.container(border=True):
                # Cálculos
                total_datos = len(df)
                if total_datos > 0:
                    datos_normales = len(df[df["Alertas"] == "Normal"])
                    pct_cumplimiento = (datos_normales / total_datos) * 100
                    num_alertas = total_datos - datos_normales
                    desviacion = df["Temp [°C]"].std()
                    promedio_kpi = df["Temp [°C]"].mean()
                else:
                    pct_cumplimiento = 0; num_alertas = 0; desviacion = 0; promedio_kpi = 0

                # Columnas para los 4 KPIs
                k1, k2, k3, k4 = st.columns(4)
                
                with k1:
                    st.metric("En Rango", f"{pct_cumplimiento:.1f}%", help="Porcentaje de datos dentro de los límites")
                with k2:
                    st.metric("N° Alertas", f"{num_alertas}", help="Cantidad total de eventos críticos")
                with k3:
                    st.metric("Desv. Estándar", f"{desviacion:.2f}", help="Variabilidad de la temperatura")
                with k4:
                    st.metric("Temp. Promedio", f"{promedio_kpi:.2f} °C", help="Promedio de toda la sesión")

	    
    # === COLUMNA DERECHA ===
    monitoreo_activo = st.session_state["monitor_live"]
    reiniciar = False
    
    with col_der:
        st.subheader("⚙️ Panel Control")
        with st.container(border=True):
            st.write("**Estado del Recorrido**")
            pct = camion_actual.porcentaje_avance
            st.progress(pct, text=f"Progreso: {int(pct*100)}%")
            st.caption(f"Tiempo: {camion_actual.pasos_completados}/{camion_actual.duracion_estimada} min")

            if camion_actual.estado == "En camino":
                st.markdown("En Tránsito")
                if st.button("Finalizar Manualmente", use_container_width=True):
                    camion_actual.finalizar_recorrido()
                    st.session_state["monitor_live"] = False
                    st.rerun()
            else:
                st.markdown("###Llegada a Destino")
                if st.button("Iniciar Nuevo Viaje", use_container_width=True):
                    camion_actual.reiniciar_recorrido()
                    st.session_state["monitor_live"] = True
                    st.rerun()

        st.write("")
        with st.container(border=True):
            st.write("**Simulación**")
            bloqueado = (camion_actual.estado == "Finalizado")
            st.toggle("Monitoreo en Vivo", key="monitor_live", disabled=bloqueado)
            monitoreo_activo = st.session_state["monitor_live"]
            if bloqueado: st.caption("Viaje finalizado.")
            elif monitoreo_activo: st.caption("Actualizando datos...")
            else: st.caption("Pausado")

        st.write("") 
        if not sensor_actual.historial_db.empty:
            prom, ult, estado, color = sensor_actual.obtener_estadisticas()
            with st.container(border=True):
                label_estado = "ESTABLE" if estado == "Normal" else f"{estado.upper()}"
                st.metric("Temperatura Actual", f"{ult:.2f} °C", delta=label_estado, delta_color=color)
        
        st.write("")
        reiniciar = st.button("Reiniciar Sensor", use_container_width=True)

    # --- RETORNO FINAL (ESTA ES LA LÍNEA QUE FALTABA O ESTABA MAL) ---
    return camion_actual, monitoreo_activo, reiniciar, archivo_subido, restaurar_btn
