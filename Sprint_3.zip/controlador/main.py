import streamlit as st
import sys
import os
import time
import pandas as pd

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from modelo.usuario import Usuario
# Importamos la nueva función
from controlador.logica import cargar_flota, cargar_estado_rapido, guardar_estado_rapido, procesar_archivo_subido, restaurar_fabrica, guardar_excel_completo
from vista.interfaz import renderizar_login, renderizar_dashboard_completo

st.set_page_config(layout="wide", page_title="ISI")

def recuperar_sesion():
    if "usuario" in st.query_params and st.query_params["usuario"] == "admin": return Usuario("admin", "admin")
    return None

def inicializar_datos():
    estado_guardado = cargar_estado_rapido()
    if estado_guardado: return estado_guardado
    return cargar_flota()

if "app_state" not in st.session_state:
    st.session_state["app_state"] = {"usuario": recuperar_sesion(), "datos": inicializar_datos()}

if st.session_state["app_state"]["usuario"] is None:
    u, p, btn = renderizar_login()
    if btn:
        admin = Usuario("admin", "admin")
        if admin.es_valido(u, p):
            st.session_state["app_state"]["usuario"] = admin
            st.query_params["usuario"] = "admin"
            if "ultimo_archivo_id" in st.session_state: del st.session_state["ultimo_archivo_id"]
            nueva_flota = cargar_flota()
            for id_camion, camion in nueva_flota.items(): camion.reiniciar_recorrido()
            st.session_state["app_state"]["datos"] = nueva_flota
            guardar_estado_rapido(nueva_flota)
            st.rerun()
        else: st.error("Credenciales incorrectas")
else:
    flota = st.session_state["app_state"]["datos"]
    if not flota: st.stop()
    camion_obj, activo, reset_btn, archivo_subido, restaurar_btn = renderizar_dashboard_completo(flota)

    if archivo_subido is not None:
        archivo_id = f"{archivo_subido.name}-{archivo_subido.size}"
        if "ultimo_archivo_id" not in st.session_state or st.session_state["ultimo_archivo_id"] != archivo_id:
            if procesar_archivo_subido(archivo_subido):
                st.session_state["ultimo_archivo_id"] = archivo_id
                nueva_flota = cargar_flota()
                st.session_state["app_state"]["datos"] = nueva_flota
                st.toast("✅ Datos cargados correctamente!", icon="📂")
                time.sleep(1); st.rerun()
            else: st.error("Error al procesar el archivo.")

    if restaurar_btn:
        restaurar_fabrica()
        if "ultimo_archivo_id" in st.session_state: del st.session_state["ultimo_archivo_id"]
        nueva_flota = cargar_flota()
        st.session_state["app_state"]["datos"] = nueva_flota
        st.toast("Sistema restaurado.", icon="🔄")
        time.sleep(1); st.rerun()

    if reset_btn:
        camion_obj.reiniciar_recorrido()
        guardar_estado_rapido(flota)
        st.rerun()

    if activo:
        time.sleep(1.5) 
        
        # 1. ACTUALIZAR MEMORIA (Rápido)
        for key, cam in flota.items():
            if cam.estado == "En camino":
                cam.simular_avance()
                if cam.estado == "En camino":
                    # Solo actualizamos RAM, no tocamos disco
                    cam.asignacion.leer_dato(origen=cam.origen, destino=cam.destino)
        
        # 2. GUARDAR EN DISCO (Una sola vez para todos)
        # Esto soluciona el problema de archivo vacío/corrupto
        guardar_excel_completo(flota)
        
        guardar_estado_rapido(flota)
        st.rerun()
