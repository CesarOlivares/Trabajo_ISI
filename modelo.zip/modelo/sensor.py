import pandas as pd
import numpy as np
import datetime
import os
from abc import ABC, abstractmethod

FILE_NAME = "camiones.xlsx" 

class Dispositivo(ABC):
    def __init__(self, id_dispositivo):
        self._id = id_dispositivo

    @property
    def id(self):
        return self._id

    @abstractmethod
    def leer_dato(self):
        pass

class Sensor(Dispositivo):
    def __init__(self, serial_id: int, umbral_max: float, umbral_min: float, historial_inicial=None):
        super().__init__(serial_id)
        self.umbral_max = umbral_max
        self.umbral_min = umbral_min
        
        self.cols_esperadas = ["Hora", "Temp [°C]", "Alertas", "LimSup", "LimInf"]
        
        # --- NUEVO: Buffer para guardar los datos del Excel que aún no se muestran ---
        self.cola_simulacion = pd.DataFrame() 
        self._backup_datos_carga = None # Para poder reiniciar usando el mismo Excel
        
        datos_validos = False
        
        if historial_inicial is not None and not historial_inicial.empty:
            if all(col in historial_inicial.columns for col in ["Hora", "Temp [°C]"]):
                
                # --- LÓGICA DE REPRODUCCIÓN (PLAYBACK) ---
                # Si el archivo tiene muchos datos (más de 21), lo dividimos:
                # 1. Los primeros 21 son el "Pasado" (se ven estáticos al inicio)
                # 2. El resto es el "Futuro" (se irán mostrando uno a uno en Live)
                
                if len(historial_inicial) > 22:
                    self.historial_db = historial_inicial.iloc[:21].copy()
                    self.cola_simulacion = historial_inicial.iloc[21:].copy()
                    
                    # Guardamos copia por si el usuario da click en "Reiniciar Sensor"
                    self._backup_datos_carga = historial_inicial.copy()
                    datos_validos = True
                else:
                    # Si tiene pocos datos, los cargamos todos como historia
                    self.historial_db = historial_inicial
                    if len(self.historial_db) >= 21:
                        datos_validos = True
        
        if not datos_validos:
            self.historial_db = pd.DataFrame(columns=self.cols_esperadas)
            self._generar_datos_iniciales()

    def _calcular_alerta(self, valor):
        if valor > self.umbral_max: return "Sobrecalentamiento"
        elif valor < self.umbral_min: return "Congelamiento"
        return "Normal"

    def _generar_datos_iniciales(self):
        """Genera datos random solo si no hay archivo"""
        now = datetime.datetime.now()
        data = []
        CANTIDAD_INICIAL = 21 
        
        for i in range(CANTIDAD_INICIAL):
            tiempo = now - datetime.timedelta(seconds=(CANTIDAD_INICIAL-i)*1.5)
            valor = round(np.random.uniform(self.umbral_min, self.umbral_max), 2)
            
            data.append({
                "Hora": tiempo.strftime("%H:%M:%S"), 
                "Temp [°C]": valor,
                "Alertas": self._calcular_alerta(valor),
                "LimSup": self.umbral_max, 
                "LimInf": self.umbral_min
            })
            
        self.historial_db = pd.concat([self.historial_db, pd.DataFrame(data)], ignore_index=True)

    def leer_dato(self, id_hoja_excel=None):
        """
        Aquí ocurre la magia: Si hay datos en la cola (del Excel), usamos esos.
        Si se acaban, empezamos a generar random.
        """
        
        # 1. ¿TENEMOS DATOS DEL EXCEL PENDIENTES?
        if not self.cola_simulacion.empty:
            # Sacamos la primera fila de la cola (FIFO)
            fila_excel = self.cola_simulacion.iloc[0]
            
            # Eliminamos esa fila de la cola para que avance
            self.cola_simulacion = self.cola_simulacion.iloc[1:]
            
            # Usamos el VALOR REAL del archivo
            valor_nuevo = float(fila_excel["Temp [°C]"])
            
            # IMPORTANTE: Usamos la hora ACTUAL del sistema para que la simulación
            # se vea fluida en el gráfico (si usáramos la hora del Excel, 
            # el gráfico podría verse cortado o viejo).
            hora_actual = datetime.datetime.now().strftime("%H:%M:%S")
            
            # Recalculamos la alerta para asegurar coherencia, o usamos la del archivo si prefieres
            alerta = self._calcular_alerta(valor_nuevo)
            
        else:
            # 2. SI SE ACABÓ EL EXCEL -> GENERAMOS RANDOM
            valor_nuevo = round(np.random.uniform(self.umbral_min - 2, self.umbral_max + 2), 2)
            hora_actual = datetime.datetime.now().strftime("%H:%M:%S")
            alerta = self._calcular_alerta(valor_nuevo)
        
        # Guardamos en el historial oficial
        nueva_fila = pd.DataFrame([{
            "Hora": hora_actual, 
            "Temp [°C]": valor_nuevo,
            "Alertas": alerta,
            "LimSup": self.umbral_max, 
            "LimInf": self.umbral_min
        }])
        
        self.historial_db = pd.concat([self.historial_db, nueva_fila], ignore_index=True)

        # Mantenemos el buffer de visualización limitado
        if len(self.historial_db) > 100:
            self.historial_db = self.historial_db.iloc[-100:]

        # Persistencia en Excel
        if id_hoja_excel:
            try:
                self._actualizar_excel(id_hoja_excel)
            except Exception as e:
                print(f"Error persistencia: {e}")

    def _actualizar_excel(self, sheet_name):
        ruta_archivo = f"../{FILE_NAME}" if os.path.exists(f"../{FILE_NAME}") else FILE_NAME
        try:
            with pd.ExcelWriter(ruta_archivo, engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
                df_meta = pd.DataFrame([{
                    "Serial_ID": self.id, "Umbral_Max": self.umbral_max, "Umbral_Min": self.umbral_min
                }])
                df_meta.to_excel(writer, sheet_name=sheet_name, index=False, startrow=0)            
                self.historial_db.to_excel(writer, sheet_name=sheet_name, index=False, startrow=3)
        except Exception:
            pass

    def reiniciar(self):
        """
        Si el usuario reinicia y había subido un Excel, volvemos a cargar 
        ese Excel desde el principio en lugar de generar random.
        """
        if self._backup_datos_carga is not None:
            # Restauramos desde la copia de seguridad del Excel
            self.historial_db = self._backup_datos_carga.iloc[:21].copy()
            self.cola_simulacion = self._backup_datos_carga.iloc[21:].copy()
        else:
            # Si no había Excel, reiniciamos a random
            self.historial_db = pd.DataFrame(columns=self.cols_esperadas)
            self._generar_datos_iniciales()
        
    def obtener_estadisticas(self):
        if self.historial_db.empty: return 0.0, 0.0, "Sin Datos", "off"
        
        promedio = self.historial_db["Temp [°C]"].mean()
        ultimo = self.historial_db.iloc[-1]["Temp [°C]"]
        
        estado = "Normal"
        alerta = "normal" 
        
        if ultimo > self.umbral_max:
            estado = "Exceso Calor"
            alerta = "inverse"
        elif ultimo < self.umbral_min:
            estado = "Congelamiento"
            alerta = "inverse"
            
        return promedio, ultimo, estado, alerta
