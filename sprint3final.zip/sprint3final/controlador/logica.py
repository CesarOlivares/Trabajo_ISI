import pandas as pd
import os
import sys
import pickle 
import random 
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

# Permite importar archivos de la carpeta anterior
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from modelo.sensor import Sensor
from modelo.camion import Camion

# Aseguramos la ruta exacta para que no se pierda buscando los archivos
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FILE_NAME = os.path.join(BASE_DIR, "camiones.xlsx") 
PICKLE_NAME = os.path.join(BASE_DIR, "estado_sesion.pkl")

CIUDADES_CHILE = ["Santiago", "Valparaíso", "Concepción", "Antofagasta", "Puerto Montt", "La Serena", "Temuco", "Arica"]

def guardar_excel_completo(flota):
    """
    Vuelca toda la info actual al Excel y le da formato para que se vea bien.
    """
    try:
        with pd.ExcelWriter(FILE_NAME, engine='openpyxl', mode='w') as writer:
            
            # Definimos los estilos: colores, bordes y letra
            header_font = Font(bold=True, color="FFFFFF")
            header_fill = PatternFill(start_color="4F81BD", end_color="4F81BD", fill_type="solid")
            data_font = Font(color="000000") 
            center_align = Alignment(horizontal='center', vertical='center')
            thin_border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))

            for id_camion, camion in flota.items():
                sensor = camion.asignacion
                sheet_name = camion.id_camion
                
                df = sensor.historial_db
                total = len(df)
                normales = len(df[df["Alertas"] == "Normal"])
                pct_ok = (normales / total * 100) if total > 0 else 0
                n_alertas = total - normales
                
                # Armamos el resumen de datos (cabecera)
                df_meta = pd.DataFrame([{
                    "Serial_ID": sensor.id, "Umbral_Max": sensor.umbral_max, "Umbral_Min": sensor.umbral_min,
                    "Inicio": camion.origen, "Destino": camion.destino, 
                    "% Dentro del umbral": round(pct_ok, 2),
                    "N° Alertas": n_alertas, 
                    "Desv. Estandar": round(df["Temp [°C]"].std(), 2),
                    "Temp. Prom": round(df["Temp [°C]"].mean(), 2)
                }])

                # Escribimos los datos en la hoja
                df_meta.to_excel(writer, sheet_name=sheet_name, index=False, startrow=0)
                sensor.historial_db.to_excel(writer, sheet_name=sheet_name, index=False, startrow=3)

                worksheet = writer.sheets[sheet_name]
                
                # Ajustamos el ancho de las columnas automaticamente
                for column in worksheet.columns:
                    max_length = 0
                    col_idx = column[0].column_letter
                    for cell in column:
                        try:
                            if len(str(cell.value)) > max_length: max_length = len(str(cell.value))
                        except: pass
                    worksheet.column_dimensions[col_idx].width = (max_length + 4)

                # Aplicamos los bordes y colores celda por celda
                for row in worksheet.iter_rows():
                    for cell in row:
                        cell.alignment = center_align
                        cell.border = thin_border
                        if cell.row == 1 or cell.row == 4:
                            cell.font = header_font
                            cell.fill = header_fill
                        else:
                            cell.font = data_font
                            cell.fill = PatternFill(fill_type=None)

    except Exception as e:
        print(f"Error guardando Excel masivo: {e}")

def gestionar_excel_inicial():
    # Si no existe el archivo, creamos uno base con datos falsos para arrancar
    if not os.path.exists(FILE_NAME):
        try:
            with pd.ExcelWriter(FILE_NAME, engine='openpyxl') as writer:
                for i in range(1, 21):
                    id_c = f"C-{i:03d}"
                    s = Sensor(1000+i, 10.0, -5.0)
                    orig = random.choice(CIUDADES_CHILE); dest = random.choice([c for c in CIUDADES_CHILE if c != orig])
                    df = s.historial_db
                    pct = (len(df[df["Alertas"]=="Normal"])/len(df)*100) if len(df)>0 else 100
                    alerts = len(df) - len(df[df["Alertas"]=="Normal"])
                    
                    meta = pd.DataFrame([{
                        "Serial_ID": 1000+i, "Umbral_Max": 10, "Umbral_Min": -5,
                        "Inicio": orig, "Destino": dest, "% Dentro del umbral": round(pct, 2),
                        "N° Alertas": alerts, "Desv. Estandar": round(df["Temp [°C]"].std(), 2), "Temp. Prom": round(df["Temp [°C]"].mean(), 2)
                    }])
                    
                    meta.to_excel(writer, sheet_name=id_c, startrow=0, index=False)
                    s.historial_db.to_excel(writer, sheet_name=id_c, startrow=3, index=False)
                    
                    # Guardamos sin estilos complejos, solo para inicializar
                    wb = writer.book; ws = writer.sheets[id_c]
                    
        except Exception as e:
            print(f"Error creando Excel: {e}")

def cargar_flota():
    gestionar_excel_inicial()
    flota = {}
    try:
        xls = pd.ExcelFile(FILE_NAME)
        for hoja in xls.sheet_names:
            try:
                
                df_check = pd.read_excel(xls, hoja, nrows=1)
                
                #Si el excel subido respeta el formato
                if "Serial_ID" in df_check.columns:
                    meta = pd.read_excel(xls, hoja, nrows=1)
                    hist = pd.read_excel(xls, hoja, skiprows=3)
                    
                    s_id = meta.iloc[0]["Serial_ID"]
                    u_max = meta.iloc[0]["Umbral_Max"]
                    u_min = meta.iloc[0]["Umbral_Min"]
                    origen = meta.iloc[0]["Inicio"] if "Inicio" in meta.columns else "Santiago"
                    destino = meta.iloc[0]["Destino"] if "Destino" in meta.columns else "Valparaíso"

                #Si se sube un formato simplificado del excel
                else:
                    hist = pd.read_excel(xls, hoja)
                    
                    try:
                        clean_name = ''.join(filter(str.isdigit, hoja))
                        s_id = int(clean_name) if clean_name else random.randint(1000, 9999)
                    except:
                        s_id = random.randint(1000, 9999)
                    
                 
                    if "LimSup" in hist.columns: u_max = float(hist.iloc[0]["LimSup"])
                    else: u_max = 10.0
                    
                    if "LimInf" in hist.columns: u_min = float(hist.iloc[0]["LimInf"])
                    else: u_min = -5.0

                   
                    if "Alertas" not in hist.columns and "Temp [°C]" in hist.columns:
                        def calcular_estado(row):
                            temp = row["Temp [°C]"]
                            if temp > u_max: return "Sobrecalentamiento"
                            if temp < u_min: return "Congelamiento"
                            return "Normal"
                        
                        hist["Alertas"] = hist.apply(calcular_estado, axis=1)
                        
                        hist["LimSup"] = u_max
                        hist["LimInf"] = u_min

                    origen = random.choice(CIUDADES_CHILE)
                    destino = random.choice([c for c in CIUDADES_CHILE if c != origen])
                
                s = Sensor(s_id, u_max, u_min, historial_inicial=hist)
                
                parts = hoja.split("-")
                num_c = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else random.randint(1, 99)
                
                duracion = len(s.cola_simulacion) if not s.cola_simulacion.empty else random.randint(25, 80)
                c = Camion(hoja, f"JJ-KL-{num_c:02d}", s, origen, destino, duracion_estimada=duracion)
                flota[str(c)] = c
            except Exception as e:
                print(f"Saltando hoja {hoja}: {e}")
                continue
    except:
        return {}
    return flota

def guardar_estado_rapido(flota):
    try:
        # Guardamos la memoria rapida (pickle)
        with open(PICKLE_NAME, 'wb') as f: pickle.dump(flota, f)
    except: pass

def cargar_estado_rapido():
    if os.path.exists(PICKLE_NAME):
        try:
            with open(PICKLE_NAME, 'rb') as f: return pickle.load(f)
        except: return None 
    return None

def procesar_archivo_subido(archivo_uploaded):
    try:
        # Sobreescribimos el Excel con el que subio el usuario
        with open(FILE_NAME, "wb") as f: f.write(archivo_uploaded.getbuffer())
        if os.path.exists(PICKLE_NAME): os.remove(PICKLE_NAME)
        return True
    except: return False

def restaurar_fabrica():
    try:
        # Borra todo para reiniciar de cero
        if os.path.exists(FILE_NAME): os.remove(FILE_NAME) 
        if os.path.exists(PICKLE_NAME): os.remove(PICKLE_NAME) 
        return True
    except: return False
