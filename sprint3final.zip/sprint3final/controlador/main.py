import streamlit as st
import sys
import os
import time
import pandas as pd

# Agrega la carpeta raíz al path para permitir importar los módulos
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from modelo.usuario import Usuario
# Importa las herramientas de manejo de datos y la interfaz gráfica
from controlador.logica import cargar_flota, cargar_estado_rapido, guardar_estado_rapido, procesar_archivo_subido, restaurar_fabrica, guardar_excel_completo
from vista.interfaz import renderizar_login, renderizar_dashboard_completo

st.set_page_config(layout="wide", page_title="ISI")

def recuperar_sesion():
    # Revisa si existe una sesión activa mirando la URL
    if "usuario" in st.query_params and st.query_params["usuario"] == "admin": return Usuario("admin", "admin")
    return None

def inicializar_datos():
    # Carga la memoria rápida (pickle) o lee el Excel desde cero si no hay datos
    estado_guardado = cargar_estado_rapido()
    if estado_guardado: return estado_guardado
    return cargar_flota()

# Si es la primera vez que inicia la app, prepara la estructura de memoria
if "app_state" not in st.session_state:
    st.session_state["app_state"] = {"usuario": recuperar_sesion(), "datos": inicializar_datos()}

# Flujo de Login
if st.session_state["app_state"]["usuario"] is None:
    u, p, btn = renderizar_login()
    if btn:
        admin = Usuario("admin", "admin")
        if admin.es_valido(u, p):
            # Guarda la sesión y limpia variables antiguas
            st.session_state["app_state"]["usuario"] = admin
            st.query_params["usuario"] = "admin"
            if "ultimo_archivo_id" in st.session_state: del st.session_state["ultimo_archivo_id"]
            
            # Carga la flota limpia al ingresar
            nueva_flota = cargar_flota()
            for id_camion, camion in nueva_flota.items(): camion.reiniciar_recorrido()
            st.session_state["app_state"]["datos"] = nueva_flota
            guardar_estado_rapido(nueva_flota)
            st.rerun()
        else: st.error("Credenciales incorrectas")
else:
    # Si ya existe login, muestra el panel principal
    flota = st.session_state["app_state"]["datos"]
    if not flota: st.stop()
    camion_obj, activo, reset_btn, archivo_subido, restaurar_btn = renderizar_dashboard_completo(flota)

    # Lógica que procesa un nuevo Excel si el usuario lo sube
    if archivo_subido is not None:
        archivo_id = f"{archivo_subido.name}-{archivo_subido.size}"
        # Verifica si es un archivo distinto al último procesado
        if "ultimo_archivo_id" not in st.session_state or st.session_state["ultimo_archivo_id"] != archivo_id:
            if procesar_archivo_subido(archivo_subido):
                st.session_state["ultimo_archivo_id"] = archivo_id
                nueva_flota = cargar_flota()
                st.session_state["app_state"]["datos"] = nueva_flota
                st.toast("✅ Datos cargados correctamente!", icon="📂")
                time.sleep(1); st.rerun()
            else: st.error("Error al procesar el archivo.")

    # Botón que elimina todo y deja el sistema limpio
    if restaurar_btn:
        restaurar_fabrica()
        if "ultimo_archivo_id" in st.session_state: del st.session_state["ultimo_archivo_id"]
        nueva_flota = cargar_flota()
        st.session_state["app_state"]["datos"] = nueva_flota
        st.toast("Sistema restaurado.", icon="🔄")
        time.sleep(1); st.rerun()

    # Reinicia solo el recorrido del camión actual
    if reset_btn:
        camion_obj.reiniciar_recorrido()
        guardar_estado_rapido(flota)
        st.rerun()

    # Bucle de simulación en tiempo real
    if activo:
        time.sleep(1.5) 
        
        # 1. Recorre la flota actualizando solo la RAM
        for key, cam in flota.items():
            if cam.estado == "En camino":
                cam.simular_avance()
                if cam.estado == "En camino":
                    # Lee el dato del sensor pero sin escribir en disco todavía
                    cam.asignacion.leer_dato(origen=cam.origen, destino=cam.destino)
        
        # 2. Guarda todo en el Excel de una sola vez
        # Esto evita errores de escritura y conflictos de archivo
        guardar_excel_completo(flota)
        
        # Guarda respaldo en pickle y recarga la página
        guardar_estado_rapido(flota)
        st.rerun()