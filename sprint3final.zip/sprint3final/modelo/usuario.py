class Usuario:
    def __init__(self, user, pwd):
        self.user = user
        self.pwd = pwd
    
    def es_valido(self, input_user, input_pwd):
        return self.user == input_user and self.pwd == input_pwd