import pandas as pd
import numpy as np
import datetime
from abc import ABC, abstractmethod

# No importa openpyxl porque el sensor ya no escribe archivos directamente
class Dispositivo(ABC):
    def __init__(self, id_dispositivo):
        self._id = id_dispositivo
    @property
    def id(self): return self._id
    @abstractmethod
    def leer_dato(self): pass

class Sensor(Dispositivo):
    def __init__(self, serial_id: int, umbral_max: float, umbral_min: float, historial_inicial=None):
        super().__init__(serial_id)
        self.umbral_max = umbral_max
        self.umbral_min = umbral_min
        self.cols_esperadas = ["Hora", "Temp [°C]", "Alertas", "LimSup", "LimInf"]
        self.cola_simulacion = pd.DataFrame() 
        self._backup_datos_carga = None 
        
        datos_validos = False
        if historial_inicial is not None and not historial_inicial.empty:
            if all(col in historial_inicial.columns for col in ["Hora", "Temp [°C]"]):
                if len(historial_inicial) > 22:
                    self.historial_db = historial_inicial.iloc[:21].copy()
                    self.cola_simulacion = historial_inicial.iloc[21:].copy()
                    self._backup_datos_carga = historial_inicial.copy()
                    datos_validos = True
                else:
                    self.historial_db = historial_inicial
                    if len(self.historial_db) >= 21: datos_validos = True
        
        if not datos_validos:
            self.historial_db = pd.DataFrame(columns=self.cols_esperadas)
            self._generar_datos_iniciales()

    def _calcular_alerta(self, valor):
        if valor > self.umbral_max: return "Sobrecalentamiento"
        elif valor < self.umbral_min: return "Congelamiento"
        return "Normal"

    def _generar_datos_iniciales(self):
        now = datetime.datetime.now()
        data = []
        for i in range(21):
            tiempo = now - datetime.timedelta(seconds=(21-i)*1.5)
            valor = round(np.random.uniform(self.umbral_min, self.umbral_max), 2)
            data.append({
                "Hora": tiempo.strftime("%H:%M:%S"), 
                "Temp [°C]": valor,
                "Alertas": self._calcular_alerta(valor),
                "LimSup": self.umbral_max, "LimInf": self.umbral_min
            })
        self.historial_db = pd.concat([self.historial_db, pd.DataFrame(data)], ignore_index=True)

    # Elimina el parámetro id_hoja_excel para no escribir en disco en cada lectura
    def leer_dato(self, id_hoja_excel=None, origen="N/A", destino="N/A"):
        # Mantiene la simulación de datos si hay cola, sino genera aleatorios
        if not self.cola_simulacion.empty:
            fila_excel = self.cola_simulacion.iloc[0]
            self.cola_simulacion = self.cola_simulacion.iloc[1:]
            valor_nuevo = float(fila_excel["Temp [°C]"])
            hora_actual = datetime.datetime.now().strftime("%H:%M:%S")
            alerta = self._calcular_alerta(valor_nuevo)
        else:
            valor_nuevo = round(np.random.uniform(self.umbral_min - 2, self.umbral_max + 2), 2)
            hora_actual = datetime.datetime.now().strftime("%H:%M:%S")
            alerta = self._calcular_alerta(valor_nuevo)
        
        nueva_fila = pd.DataFrame([{
            "Hora": hora_actual, "Temp [°C]": valor_nuevo,
            "Alertas": alerta, "LimSup": self.umbral_max, "LimInf": self.umbral_min
        }])
        
        self.historial_db = pd.concat([self.historial_db, nueva_fila], ignore_index=True)
        if len(self.historial_db) > 100:
            self.historial_db = self.historial_db.iloc[-100:]
        
        # Evita guardar el Excel en cada paso para prevenir errores de escritura

    def reiniciar(self):
        if self._backup_datos_carga is not None:
            self.historial_db = self._backup_datos_carga.iloc[:21].copy()
            self.cola_simulacion = self._backup_datos_carga.iloc[21:].copy()
        else:
            self.historial_db = pd.DataFrame(columns=self.cols_esperadas)
            self._generar_datos_iniciales()
        
    def obtener_estadisticas(self):
        if self.historial_db.empty: return 0.0, 0.0, "Sin Datos", "off"
        promedio = self.historial_db["Temp [°C]"].mean()
        ultimo = self.historial_db.iloc[-1]["Temp [°C]"]
        estado = "Normal"; alerta = "normal" 
        if ultimo > self.umbral_max: estado = "Exceso Calor"; alerta = "inverse"
        elif ultimo < self.umbral_min: estado = "Congelamiento"; alerta = "inverse"
        return promedio, ultimo, estado, alerta