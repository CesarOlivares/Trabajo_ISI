import random

class Camion:
    def __init__(self, id_camion: str, patente: str, sensor_asignado, origen="Santiago", destino="Valparaíso", estado="En camino", duracion_estimada=30):
        self.id_camion = id_camion
        self.patente = patente
        self.asignacion = sensor_asignado
        
        self.origen = origen
        self.destino = destino
        self.estado = estado 
        
        self.duracion_estimada = duracion_estimada 
        self.pasos_completados = 0                 
        
        if estado == "Finalizado":
            self.pasos_completados = self.duracion_estimada

    def finalizar_recorrido(self):
        self.estado = "Finalizado"
        self.pasos_completados = self.duracion_estimada 

    def reiniciar_recorrido(self):
        self.estado = "En camino"
        self.pasos_completados = 0 
        
        # Reinicia el sensor recargando la cola de datos desde el respaldo
        self.asignacion.reiniciar()
        
        # Revisa si el sensor tiene datos reales pendientes por procesar
        if not self.asignacion.cola_simulacion.empty:
            # Ajusta la duración total basándose en los datos del archivo
            self.duracion_estimada = len(self.asignacion.cola_simulacion)
            # Mantiene origen y destino para repetir el viaje exactamente igual
            
        else:
            # Si no hay datos de archivo, genera una ruta y tiempo al azar
            ciudades = ["Santiago", "Valparaíso", "Concepción", "Antofagasta", "Puerto Montt", "La Serena", "Temuco", "Arica", "Iquique", "Punta Arenas"]
            if self.origen in ciudades:
                self.origen = random.choice(ciudades)
                self.destino = random.choice([c for c in ciudades if c != self.origen])
            
            self.duracion_estimada = random.randint(20, 60)

    def simular_avance(self):
        if self.estado == "En camino":
            self.pasos_completados += 1
            if self.pasos_completados >= self.duracion_estimada:
                self.finalizar_recorrido()
                return True 
        return False

    @property
    def porcentaje_avance(self):
        if self.duracion_estimada == 0: return 1.0 # Evita errores de división por cero
        pct = self.pasos_completados / self.duracion_estimada
        return min(pct, 1.0) 

    def __str__(self):
        icon = "🟢" if self.estado == "En camino" else "🔴"
        return f"{icon} {self.id_camion} | {self.patente}"